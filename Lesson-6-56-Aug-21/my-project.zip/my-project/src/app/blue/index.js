export { makeItBlue } from './blue'
