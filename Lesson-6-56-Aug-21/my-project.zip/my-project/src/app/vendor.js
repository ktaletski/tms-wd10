/**
 * Adds polyfills for ECMAScript up to 2023
 * @see https://www.npmjs.com/package/core-js
 */
import 'core-js/stable';
