const files = require('./files');
const scripts = require('./scripts');
const styles = require('./styles');

module.exports = {
  files,
  scripts,
  styles,
};
